package com.tonystark.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat

/**
 * Service de premier plan (foreground service) qui garde le microphone en ecoute pour
 * detecter le mot de reveil "Jarvis" MEME quand l'application est totalement fermee.
 *
 * Contrainte Android : le WebView/JS de la PWA est completement suspendu des que
 * l'appli n'est plus visible — il ne peut donc pas ecouter en arriere-plan. Ce service
 * natif independant prend le relai avec l'API native SpeechRecognizer d'Android : il
 * ecoute en continu (par segments), et des qu'il entend "Jarvis", il vibre pour
 * confirmer puis relance l'appli, qui reprend alors la conversation vocale complete
 * (reconnaissance + IA + voix) via sa logique JS habituelle.
 *
 * Il se met automatiquement en pause quand l'appli est au premier plan (pour laisser
 * le micro au WebView) et reprend des que l'appli repasse en arriere-plan/est fermee,
 * tant que l'utilisateur n'a pas desactive le mode depuis les reglages.
 */
class JarvisListenService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pausedForForeground = false
    private var destroyed = false

    private val wakeWords = listOf("jarvis", "jarviss", "jarvys", "jarvi", "djarvis", "charvis", "jarvice")

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
        startForeground(NOTIF_ID, buildNotification("En veille — dites « Jarvis » pour l'activer"))
        if (!pausedForForeground) startCycle()
        return START_STICKY
    }

    override fun onDestroy() {
        destroyed = true
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        instance = null
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    // ---------- cycle d'ecoute ----------

    private fun startCycle() {
        if (destroyed || pausedForForeground) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // Peut etre temporaire (app Google pas encore prete au demarrage du telephone,
            // mise a jour en cours...) : on reessaie plutot que d'abandonner definitivement.
            updateNotification("Reconnaissance vocale indisponible pour le moment — nouvelle tentative...")
            handler.postDelayed({ startCycle() }, 5000)
            return
        }
        // On recree TOUJOURS un SpeechRecognizer neuf a chaque cycle. Reutiliser la meme
        // instance sur de nombreux cycles start/stop consecutifs la fait souvent se coincer
        // dans un etat casse sur certains appareils/versions Android : elle continue a
        // "beeper" (le son de debut d'ecoute) mais echoue systematiquement juste apres,
        // sans jamais reussir a capter de parole. Recreer une instance fraiche a chaque
        // fois evite ce blocage.
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val recoIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            // Apres plusieurs erreurs reseau d'affilee, on bascule en mode hors-ligne
            // (si un modele offline est installe sur l'appareil) plutot que de continuer
            // a echouer indefiniment faute de connexion.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, consecutiveNetworkErrors >= 2)
        }
        try {
            recognizer?.startListening(recoIntent)
        } catch (e: Exception) {
            handler.postDelayed({ startCycle() }, 1200)
        }
    }

    private fun restartSoon(delayMs: Long = 400) {
        handler.postDelayed({ if (!destroyed && !pausedForForeground) startCycle() }, delayMs)
    }

    private var consecutiveNetworkErrors = 0

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                consecutiveNetworkErrors++
            } else if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                consecutiveNetworkErrors = 0
            }
            // ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT : normal en veille silencieuse, on relance vite.
            val delay = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 250L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 800L
                else -> 600L
            }
            // Diagnostic temporaire : affiche le code d'erreur dans la notification pour
            // pouvoir identifier precisement ce qui bloque si le probleme persiste.
            updateNotification("En veille (dernier code d'erreur : $error) — dites « Jarvis »")
            restartSoon(delay)
        }

        override fun onResults(results: Bundle?) {
            consecutiveNetworkErrors = 0
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val query = matches?.firstNotNullOfOrNull { extractQueryAfterWakeWord(it) }
            if (query != null) {
                triggerWake(query)
            } else {
                restartSoon(150)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            // On n'agit plus sur les resultats PARTIELS : couper l'ecoute des que "Jarvis" est
            // detecte au milieu d'une phrase coupait le micro avant que la question posee dans
            // la meme respiration ("Jarvis, quelle heure est-il ?") ne soit captee. On attend
            // desormais le resultat FINAL (fin de phrase / silence detecte par le reconnaisseur)
            // pour recuperer le mot de reveil ET la question en une seule fois.
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    /**
     * Cherche le mot de reveil dans la phrase et renvoie ce qui le suit (la question),
     * ou une chaine vide si "Jarvis" a ete dit seul. Renvoie null si aucun mot de reveil
     * n'est present dans la phrase.
     */
    private fun extractQueryAfterWakeWord(phrase: String): String? {
        val lower = phrase.lowercase()
        for (w in wakeWords) {
            val idx = lower.indexOf(w)
            if (idx >= 0) {
                return phrase.substring(idx + w.length)
                    .trim()
                    .trimStart(',', '.', '!', '?', ':', ' ')
                    .trim()
            }
        }
        return null
    }

    private fun triggerWake(query: String) {
        try { recognizer?.stopListening() } catch (e: Exception) {}
        vibrate()
        updateNotification("Reveil detecte — ouverture de JARVIS…")

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_WAKE_TRIGGERED, true)
            // La question a deja ete captee par le meme resultat de reconnaissance que le mot
            // de reveil : on la transmet a l'appli pour qu'elle reponde direct, sans attendre
            // que l'utilisateur reparle une fois l'appli rouverte.
            if (query.isNotBlank()) putExtra(MainActivity.EXTRA_WAKE_QUERY, query)
        }
        startActivity(launchIntent)
        // Le cycle d'ecoute natif se remet en pause automatiquement quand MainActivity
        // passe au premier plan (voir notifyAppForeground), pour laisser le micro au WebView.
    }

    private fun vibrate() {
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(120)
        }
    }

    // ---------- notification persistante ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Ecoute JARVIS", NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Indique que JARVIS ecoute le mot de reveil en arriere-plan"
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, JarvisListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Arreter l'ecoute", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    // ---------- pilotage depuis MainActivity (pause quand l'appli est au premier plan) ----------

    private fun doPauseForForeground() {
        pausedForForeground = true
        try { recognizer?.cancel() } catch (e: Exception) {}
        handler.removeCallbacksAndMessages(null)
        updateNotification("JARVIS actif dans l'appli — veille en pause")
    }

    private fun doResumeForBackground() {
        pausedForForeground = false
        updateNotification("En veille — dites « Jarvis » pour l'activer")
        startCycle()
    }

    companion object {
        private const val CHANNEL_ID = "jarvis_listen_channel"
        private const val NOTIF_ID = 42
        private const val PREFS = "jarvis_service_prefs"
        private const val KEY_ENABLED = "background_listen_enabled"
        const val ACTION_STOP = "com.tonystark.jarvis.action.STOP"

        private var instance: JarvisListenService? = null

        val isRunning: Boolean get() = instance != null

        fun start(context: Context) {
            val intent = Intent(context, JarvisListenService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, JarvisListenService::class.java).setAction(ACTION_STOP))
        }

        fun wasEnabledByUser(context: Context): Boolean {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false)
        }

        /** Appele par MainActivity quand l'appli passe au premier plan. */
        fun notifyAppForeground() {
            instance?.doPauseForForeground()
        }

        /** Appele par MainActivity quand l'appli passe en arriere-plan / est fermee. */
        fun notifyAppBackground() {
            instance?.doResumeForBackground()
        }
    }
}
