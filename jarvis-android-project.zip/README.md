# JARVIS — app Android (wrapper natif + écoute en arrière-plan)

Ce dossier est un projet Android complet (Gradle) qui embarque ta PWA JARVIS
(`app/src/main/assets/www/`, inchangée dans son contenu) dans une WebView native,
et ajoute un **service natif d'écoute du mot de réveil « Jarvis »** qui continue de
tourner même quand l'application est fermée ou l'écran éteint.

## Comment obtenir l'APK (sans rien installer sur ton PC)

1. Crée un nouveau dépôt GitHub (ou utilise un dépôt existant).
2. Pousse **tout le contenu de ce dossier** à la racine du dépôt (le fichier
   `.github/workflows/build-apk.yml` doit se trouver à `.github/workflows/...`).
3. Va dans l'onglet **Actions** du dépôt GitHub : le workflow « Build JARVIS APK »
   se lance automatiquement à chaque push sur `main`/`master` (ou lance-le à la main
   avec le bouton « Run workflow »).
4. Une fois le workflow terminé (icône verte), ouvre l'exécution puis la rubrique
   **Artifacts** en bas de page : télécharge `jarvis-debug-apk` (un .zip contenant
   le `.apk`).
5. Transfère l'APK sur ton téléphone (Drive, mail, câble...) et installe-le en
   autorisant « sources inconnues » si Android le demande.

Aucune compilation locale n'est nécessaire : tout se fait sur les serveurs GitHub.

## Ce qui a été ajouté par rapport à la PWA d'origine

- **`MainActivity.kt`** : charge `index.html` dans une WebView (via
  `WebViewAssetLoader`, ce qui permet à la géolocalisation et aux autres API web de
  fonctionner correctement, contrairement à un simple `file://`). Elle gère les
  permissions Android (micro, caméra, position, notifications) et expose un pont
  `window.AndroidBridge` au JavaScript de la page.
- **`JarvisListenService.kt`** : un service de premier plan (notification
  persistante obligatoire sous Android) qui utilise l'API native
  `SpeechRecognizer` pour écouter en boucle et détecter le mot « Jarvis », y
  compris appli fermée. Dès qu'il l'entend : vibration courte + réouverture de
  l'appli, qui reprend alors la conversation vocale complète (reconnaissance,
  appel à Gemini, synthèse vocale) via ta logique JS existante, inchangée.
- Dans `index.html` : un nouveau réglage **« Écoute en arrière-plan »** (visible
  uniquement dans l'appli empaquetée, pas dans un navigateur) qui active/désactive
  ce service, et une fonction `window.onJarvisWake()` appelée automatiquement au
  réveil pour relancer le micro comme si tu venais d'appuyer sur le bouton.
- Le service se met en pause automatiquement dès que l'appli repasse au premier
  plan (pour ne pas se disputer le micro avec la reconnaissance vocale de la
  page), et reprend dès qu'elle repasse en arrière-plan.

## Limites techniques importantes (à savoir avant d'utiliser ça au quotidien)

- **Ce n'est pas magique** : Android suspend tout JavaScript dès que l'appli
  n'est plus visible. Il est donc impossible de faire tourner *ta logique JS*
  (Gemini, TTS, etc.) en tâche de fond. La seule chose qui peut réellement
  tourner en fond est un service natif — c'est ce que fait `JarvisListenService`,
  mais uniquement pour la détection du mot de réveil, pas pour la conversation
  entière.
- **Notification obligatoire** : Android impose qu'un service utilisant le micro
  en arrière-plan affiche une notification persistante tant qu'il écoute (visible
  dans la barre de notifications, avec un bouton « Arrêter l'écoute »). C'est une
  contrainte du système, pas un choix de conception.
- **Fiabilité variable selon le téléphone** : certains fabricants (Xiaomi,
  Huawei, Samsung en mode économie d'énergie agressif...) tuent les services en
  arrière-plan malgré tout. Si l'écoute s'arrête toute seule après un moment,
  il faudra désactiver l'optimisation de batterie pour JARVIS dans les réglages
  système du téléphone.
- **`SpeechRecognizer` natif dépend de Google** : il utilise les services vocaux
  Google installés sur le téléphone (comme la reconnaissance vocale classique
  d'Android) ; sur un appareil sans Google Play Services, ça ne fonctionnera pas.
- **Consommation de batterie** : une écoute vocale continue consomme plus de
  batterie qu'une appli fermée normale, même optimisée par le système.
- Le workflow compile actuellement un **APK debug non signé pour la release**
  (signature debug automatique de Gradle) — largement suffisant pour installer
  sur ton propre téléphone. Pour publier sur le Play Store, il faudrait générer
  un keystore de release et l'ajouter en secret GitHub (dis-le-moi si tu veux
  que je mette ça en place).

## Développer/tester en local (optionnel)

Si tu as Android Studio : ouvre simplement ce dossier comme projet existant,
laisse Gradle se synchroniser, puis lance sur un appareil/émulateur.
