package com.tonystark.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Activité unique : charge la PWA JARVIS depuis les assets locaux (file:///android_asset/www/)
 * et expose un pont JS <-> natif (AndroidBridge) pour piloter le service d'écoute
 * en arrière-plan (mot de reveil "Jarvis" actif meme appli fermee).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val runtimePermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    ).let {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            it + Manifest.permission.POST_NOTIFICATIONS
        } else it
    }

    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingGeoOrigin: String? = null
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        setupWebView()
        requestStartupPermissions()

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")

        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    /** Si l'appli est ouverte suite a la detection du mot de reveil par le service, on relance l'ecoute complete cote JS. */
    private fun handleWakeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_WAKE_TRIGGERED, false) == true) {
            webView.post {
                webView.evaluateJavascript(
                    "window.onJarvisWake && window.onJarvisWake();",
                    null
                )
            }
        }
    }

    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setGeolocationEnabled(true)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = false
        settings.allowContentAccess = false

        val assetLoader = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val granted = request.resources.all { res ->
                        when (res) {
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            else -> true
                        }
                    }
                    if (granted) request.grant(request.resources) else request.deny()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val ok = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback.invoke(origin, ok, false)
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                pendingFileCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), REQUEST_FILE_CHOOSER)
                    true
                } catch (e: Exception) {
                    pendingFileCallback = null
                    false
                }
            }
        }

        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_FILE_CHOOSER) {
            val results = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            pendingFileCallback?.onReceiveValue(results)
            pendingFileCallback = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun requestStartupPermissions() {
        val missing = runtimePermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_PERMS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // La PWA gere elle-meme la demande de permission micro/camera/geoloc via ses propres
        // boutons ; ceci ne fait que preparer le terrain au demarrage pour eviter les refus WebView.
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        // L'appli reprend la main sur le micro : le service natif se met en veille silencieuse.
        JarvisListenService.notifyAppForeground()
    }

    override fun onPause() {
        super.onPause()
        // L'appli passe en arriere-plan (ou l'ecran s'eteint) : si le mode etait active,
        // le service natif reprend l'ecoute du mot de reveil.
        if (JarvisListenService.wasEnabledByUser(this)) {
            JarvisListenService.notifyAppBackground()
        }
    }

    companion object {
        const val EXTRA_WAKE_TRIGGERED = "WAKE_TRIGGERED"
        private const val REQUEST_PERMS = 4200
        private const val REQUEST_FILE_CHOOSER = 4300
    }

    /** Pont expose au JS de la PWA sous window.AndroidBridge */
    class AndroidBridge(private val activity: MainActivity) {

        @android.webkit.JavascriptInterface
        fun startBackgroundListen() {
            activity.runOnUiThread {
                val hasMic = ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    Toast.makeText(activity, "Autorise le microphone d'abord dans les reglages JARVIS.", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                JarvisListenService.start(activity)
                Toast.makeText(activity, "Ecoute JARVIS active en arriere-plan.", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun stopBackgroundListen() {
            activity.runOnUiThread {
                JarvisListenService.stop(activity)
                Toast.makeText(activity, "Ecoute en arriere-plan desactivee.", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isBackgroundListenActive(): Boolean {
            return JarvisListenService.isRunning
        }
    }
}
