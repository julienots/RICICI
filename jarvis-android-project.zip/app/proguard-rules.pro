# Règles ProGuard - vide pour l'instant, minify désactivé par défaut.
