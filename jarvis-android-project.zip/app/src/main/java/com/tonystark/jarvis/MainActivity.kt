package com.tonystark.jarvis

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Activité unique : charge la PWA JARVIS depuis les assets locaux (file:///android_asset/www/)
 * et expose un pont JS <-> natif (AndroidBridge) pour piloter le service d'écoute
 * en arrière-plan (mot de reveil "Jarvis" actif meme appli fermee).
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView

    // Synthese vocale NATIVE Android (voix systeme, bien meilleure qualite que la
    // speechSynthesis du WebView qui n'a souvent aucune voix correcte disponible).
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val runtimePermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    ).let {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            it + Manifest.permission.POST_NOTIFICATIONS
        } else it
    }

    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingGeoOrigin: String? = null
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        setupWebView()
        requestStartupPermissions()
        tts = TextToSpeech(this, this)

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")

        handleWakeIntent(intent)
    }

    /** TextToSpeech.OnInitListener : appele quand le moteur de voix natif est pret. */
    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            return
        }
        val engine = tts ?: return
        val result = engine.setLanguage(Locale.FRANCE)
        ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        // Prend la meilleure voix francaise disponible sur l'appareil (qualite reseau/network
        // si presente, sinon la voix locale par defaut deja selectionnee ci-dessus).
        try {
            val bestVoice: Voice? = engine.voices
                ?.filter { it.locale.language == "fr" && !it.isNetworkConnectionRequired }
                ?.maxByOrNull { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) (5 - it.quality) * -1 else 0 }
            if (bestVoice != null) engine.voice = bestVoice
        } catch (e: Exception) { /* tant pis, on garde la voix par defaut de la locale */ }
        engine.setSpeechRate(1.0f)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                webView.post {
                    webView.evaluateJavascript(
                        "window.onNativeTtsStart && window.onNativeTtsStart(${jsStringLiteral(utteranceId)});",
                        null
                    )
                }
            }
            override fun onDone(utteranceId: String?) {
                webView.post {
                    webView.evaluateJavascript(
                        "window.onNativeTtsEnd && window.onNativeTtsEnd(${jsStringLiteral(utteranceId)});",
                        null
                    )
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                webView.post {
                    webView.evaluateJavascript(
                        "window.onNativeTtsError && window.onNativeTtsError(${jsStringLiteral(utteranceId)});",
                        null
                    )
                }
            }
        })
    }

    private fun jsStringLiteral(s: String?): String {
        val safe = (s ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
        return "\"$safe\""
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    /**
     * Si l'appli est ouverte suite a la detection du mot de reveil par le service natif :
     * transmet au JS la question deja captee (dite dans la meme phrase que "Jarvis"), si
     * il y en a une, pour qu'il reponde directement au lieu de rouvrir un micro qui
     * n'entendrait plus rien (l'utilisateur a deja fini de parler a ce moment-la).
     */
    private fun handleWakeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_WAKE_TRIGGERED, false) == true) {
            val query = intent.getStringExtra(EXTRA_WAKE_QUERY)
            webView.post {
                webView.evaluateJavascript(
                    "window.onJarvisWake && window.onJarvisWake(${jsStringLiteral(query)});",
                    null
                )
            }
        }
    }

    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setGeolocationEnabled(true)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = false
        settings.allowContentAccess = false

        val assetLoader = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            // CRITIQUE : sans ceci, une WebView ignore ou plante silencieusement sur tout
            // schema qu'elle ne sait pas afficher elle-meme (tel:, sms:, mailto:, geo:,
            // market:, intent:, whatsapp:, waze:, android-app:...), et les liens "deep link"
            // http(s) vers d'autres applis (wa.me, maps.google.com...) restent juste charges
            // DANS la WebView au lieu d'ouvrir l'appli native. C'est la cause principale du
            // "JARVIS ne fait rien" quand on lui demande d'appeler/ouvrir une appli/envoyer un SMS.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                // Notre propre contenu (assets locaux) : on laisse la WebView le charger normalement.
                if (url.host == "appassets.androidplatform.net") return false
                return launchExternally(url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val granted = request.resources.all { res ->
                        when (res) {
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            else -> true
                        }
                    }
                    if (granted) request.grant(request.resources) else request.deny()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val ok = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback.invoke(origin, ok, false)
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                pendingFileCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), REQUEST_FILE_CHOOSER)
                    true
                } catch (e: Exception) {
                    pendingFileCallback = null
                    false
                }
            }
        }

        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_FILE_CHOOSER) {
            val results = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            pendingFileCallback?.onReceiveValue(results)
            pendingFileCallback = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * Ouvre une URL/URI (tel:, sms:, mailto:, geo:, market:, http(s) deep link vers une
     * appli tierce, etc.) dans l'appli native correspondante via un Intent Android standard.
     * Retourne true si on a pris en charge la navigation (que ca ait reussi ou echoue avec
     * un message a l'utilisateur), false si on veut laisser la WebView gerer elle-meme.
     */
    private fun launchExternally(uri: Uri): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Aucune application installee pour ouvrir : $uri", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Impossible d'ouvrir : $uri", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun requestStartupPermissions() {
        val missing = runtimePermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_PERMS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // La PWA gere elle-meme la demande de permission micro/camera/geoloc via ses propres
        // boutons ; ceci ne fait que preparer le terrain au demarrage pour eviter les refus WebView.
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        // L'appli reprend la main sur le micro : le service natif se met en veille silencieuse.
        JarvisListenService.notifyAppForeground()
    }

    override fun onPause() {
        super.onPause()
        // L'appli passe en arriere-plan (ou l'ecran s'eteint) : si le mode etait active,
        // le service natif reprend l'ecoute du mot de reveil.
        if (JarvisListenService.wasEnabledByUser(this)) {
            JarvisListenService.notifyAppBackground()
        }
    }

    companion object {
        const val EXTRA_WAKE_TRIGGERED = "WAKE_TRIGGERED"
        const val EXTRA_WAKE_QUERY = "WAKE_QUERY"
        private const val REQUEST_PERMS = 4200
        private const val REQUEST_FILE_CHOOSER = 4300
    }

    /** Pont expose au JS de la PWA sous window.AndroidBridge */
    class AndroidBridge(private val activity: MainActivity) {

        @android.webkit.JavascriptInterface
        fun startBackgroundListen() {
            activity.runOnUiThread {
                val hasMic = ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    Toast.makeText(activity, "Autorise le microphone d'abord dans les reglages JARVIS.", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                JarvisListenService.start(activity)
                Toast.makeText(activity, "Ecoute JARVIS active en arriere-plan.", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun stopBackgroundListen() {
            activity.runOnUiThread {
                JarvisListenService.stop(activity)
                Toast.makeText(activity, "Ecoute en arriere-plan desactivee.", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isBackgroundListenActive(): Boolean {
            return JarvisListenService.isRunning
        }

        // ---------- synthese vocale native (bien meilleure qualite que speechSynthesis WebView) ----------

        @android.webkit.JavascriptInterface
        fun isNativeTtsReady(): Boolean = activity.ttsReady

        @android.webkit.JavascriptInterface
        fun speakNative(text: String, utteranceId: String) {
            activity.runOnUiThread {
                val engine = activity.tts
                if (engine == null || !activity.ttsReady) return@runOnUiThread
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
        }

        @android.webkit.JavascriptInterface
        fun stopNativeSpeech() {
            activity.runOnUiThread { activity.tts?.stop() }
        }

        // ---------- fiabilite de l'ecoute en arriere-plan ----------

        /** Demande a l'utilisateur d'exclure JARVIS de l'optimisation de batterie, sinon
         *  certains fabricants (Xiaomi, Samsung...) tuent le service d'ecoute au bout d'un moment. */
        @android.webkit.JavascriptInterface
        fun requestIgnoreBatteryOptimizations() {
            activity.runOnUiThread {
                try {
                    val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
                    if (!pm.isIgnoringBatteryOptimizations(activity.packageName)) {
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${activity.packageName}")
                        }
                        activity.startActivity(intent)
                    }
                } catch (e: Exception) { /* pas grave, purement une amelioration de fiabilite */ }
            }
        }

        // ---------- ouverture directe d'une appli/action externe depuis le JS ----------

        /** Ouvre une URL/URI externe (tel:, sms:, mailto:, http(s), deep link...) via un Intent natif.
         *  Utilise en secours par le JS pour les cas ou window.location.href ne suffit pas. */
        @android.webkit.JavascriptInterface
        fun openExternal(uri: String) {
            activity.runOnUiThread {
                activity.launchExternally(Uri.parse(uri))
            }
        }
    }
}
