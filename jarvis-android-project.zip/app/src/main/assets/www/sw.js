// Service worker J.A.R.V.I.S.
// Met en cache la coquille de l'app pour permettre l'installation et un lancement
// hors-ligne (les appels a l'API Gemini necessitent toujours une connexion).

const CACHE_NAME = 'jarvis-shell-v5';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png'
];

// installation : met en cache la coquille de l'app
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

// activation : nettoie les anciennes versions du cache
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// strategie : reseau d'abord pour la coquille de l'app (garantit d'avoir toujours la
// derniere version deployee quand une connexion est dispo), cache en secours hors-ligne
// uniquement. Avant : "cache d'abord" gardait indefiniment une vieille version en cache
// meme apres un redeploiement sur Netlify, car le nom du cache ne changeait jamais.
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // ne jamais intercepter les appels API externes
  if (url.origin !== self.location.origin) return;
  if (req.method !== 'GET') return;

  event.respondWith(
    fetch(req).then((res) => {
      if (res && res.status === 200) {
        const clone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
      }
      return res;
    }).catch(() => {
      // hors-ligne : on retombe sur le cache (version la plus recente connue)
      return caches.match(req).then((cached) => {
        if (cached) return cached;
        if (req.mode === 'navigate') return caches.match('./index.html');
      });
    })
  );
});
